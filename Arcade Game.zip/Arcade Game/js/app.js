var score = 0;
var MAX = 380;
var MIN = 80;
var Enemy = function(c, d){
    this.sprite = 'images/enemy-bug.png';
    this.c = c;
    this.d = d;
    this.speed = this.getspeed();
};

Enemy.prototype.getspeed = function(){
    var speed = Math.floor(Math.random()*(MAX-MIN+1)+MIN);
    return speed;
}

Enemy.prototype.update = function(dt){
    if(this.c < 500)
         this.c = this.c + this.speed * dt;
    else {
         this.c = -100;
        this.speed = this.getspeed();
    }
};

Enemy.prototype.render = function(){
    ctx.drawImage(Resources.get(this.sprite), this.c, this.d);
};

var Player = function(c, d){
    this.sprite = 'images/char-boy.png';
    this.c = c;
    this.d = d;
};
document.addEventListener('keyup', function(e){
    var usedKeys ={
        37: 'left',
        38: 'up',
        39: 'right',
        40: 'down',
        65: 'left',
    };
    player.handleInput(usedKeys[e.keyCode]);
});



Player.prototype.update = function(){
    var i;
    for(i = 0; i < allEnemies.length; i++){
             if((this.d == allEnemies[i].d) && (this.c < allEnemies[i].c + 101) && (this.c + 101 > allEnemies[i].c))
                this.reset();

            }
};

Player.prototype.render = function(){
    ctx.drawImage(Resources.get(this.sprite), this.c, this.d);
}

Player.prototype.reset = function(){
    this.c = 200;
    this.d = 400;
};

Player.prototype.handleInput = function(key){
	       // Key inputs, on detection of key this function moves the player according to the key pressed.
    if(key == 'left'){
        if(this.c > 0) this.c -= 100;
    }
        else if(key == 'right'){
            if(this.c  < 400)
                this.c = this.c + 100;
        }
    else if(key == 'up'){
        if(this.d > 40){
            this.d = this.d - 90;
        }
        else{
            score = score + 1;
            $('#score').text(score);
            this.reset();
        }
    } else if(key == 'down'){
        if(this.d < 400){
            this.d = this.d + 90;
        }
    }
};

var allEnemies = [
new Enemy(0, 40),
new Enemy(0, 130),
new Enemy(0, 220),
];

var player = new Player(200, 400);